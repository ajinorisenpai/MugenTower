## Dependencies ##

  * [jumandic.jppmdl](https://github.com/ku-nlp/jumanpp/releases)

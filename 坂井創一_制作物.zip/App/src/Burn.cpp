//
//  Effect.cpp
//  empty
//
//  Created by 坂井創一 on 2019/08/26.
//

#include "Burn.hpp"

﻿//
//  SceneChange.hpp
//  empty
//
//  Created by 坂井創一 on 2019/08/10.
//

#ifndef SceneChange_h
#define SceneChange_h


#endif /* SceneChange_h */

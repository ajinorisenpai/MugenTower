﻿#include "Burn.hpp"

﻿#include "Actor.hpp"
#include "Game.hpp"

Actor::Actor(Game* m_game):mState(State::Active),m_game(m_game){
    
}
